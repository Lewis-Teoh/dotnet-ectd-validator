<?xml version="1.0" encoding="UTF-8"?>
<!-- U.S. Regional Stylesheet  (us-regional.xsl) -->
<!-- version 1-0 -->
<xsl:stylesheet version="1.1" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"			
	xmlns="http://www.w3.org/1999/xhtml"
	xmlns:fo="http://www.w3.org/1999/XSL/Format" 
	xmlns:xlink="http://www.w3c.org/1999/xlink" 
	xmlns:internal="http://www.ich.org"
	xmlns:fda-regional="http://www.ich.org/fda"
	xmlns:msxsl="urn:schemas-microsoft-com:xslt"
	xmlns:js="javascript:code">

	<msxsl:script language="javascript" implements-prefix="js">
		
		<![CDATA[
		
		// Vars
		var defFontStr = "font-family: Tahoma, Arial, sans-serif";
		var indent = 1;
		var title = "eCTD";
		var unique = 0;
		var parentTitle;
		 
		function getUnique() // Return value of unique counter
		{
			return unique;
		}
				
		function getIndent() // Returns an indent
		{ 
			return indent;
		}
				
		function getCSSRule(ruleNo) // Returns the corresponding CSS rule
		{ 
			if(ruleNo == "0") return defFontStr + "; background-color: white";
			if(ruleNo == "1") return  defFontStr + "; font-size: 16px";
			if(ruleNo == "2") return  defFontStr + "; font-size: 14px";
			if(ruleNo == "3") return  defFontStr + "; font-size: 10px";
			if(ruleNo == "4") return defFontStr + "; font-size: 20px; color: #FFFFFF; background-color: #3366CC; font-weight: bold";
			if(ruleNo == "5") return getCSSRule('2') + "; font-weight: bold; color: #333333; background-color: white";
			if(ruleNo == "6") return defFontStr + "; font-size: 12px; font-weight: bold; color: blue; background-color: #ECECEC";
			if(ruleNo == "7") return  defFontStr + "; font-size: 14px; font-weight: bold; color: #ECECEC; background-color: #ECECEC";
			if(ruleNo == "8") return  "font-family: Verdana, Geneva, Arial, Helvetica, sans-serif; font-size: 14px; font-weight: bold; color: #CCCCCC; background-color: #CCCCCC";
			if(ruleNo == "9") return defFontStr + "; font-size: 12px; font-weight: bold; color: #B9290D; background-color: #ECECEC";
			if(ruleNo == "10") return "font-family: \"MS Sans Serif\"; font-size: 14px; background-color: light-gray";
			if(ruleNo == "11") return defFontStr + "; font-size: 16px; font-weight: bold; color: #FFFFFF";
			if(ruleNo == "12") return "visited {text-decoration: none; color: blue;}";
			if(ruleNo == "13") return "hover {text-decoration: none;color: #047E7D;}";
			if(ruleNo == "14") return "link {text-decoration: none; color: #070BA7; text-decoration: none;}";
			if(ruleNo == "15") return "active {text-decoration: none;}";
			if(ruleNo == "16") return defFontStr + "; font-size: 9px;";	
		}

		function getTitle() // Returns the correct document title
		{
			return title;
		}
		
		function setParentTitle(pTitle)
		{
			parentTitle = pTitle;
			return pTitle;
		}
		
		function getParentTitle()
		{
			return parentTitle;
		}	
				
		function getAlert(param) // Displays the appropriate alert message
		{
			// Vars
			var mes = new Array();

			mes[0] = "This is not a real file, the file is not a valid xml file, "
				+ "\\r\\nor a required node is missing.  This stylesheet only supports "
				+ "\\r\\nXML files that use correct WC3 XML syntax and conform to the "
				+ "\\r\\nDTD referenced in the selected file.  Please check the syntax "
				+ "\\r\\nand location of the selected file and try again.";
			mes[1] = "Your browser security settings do not permit this action.";
			mes[2] = "Node not found.  Check reference to FDA Regional instance.";
			mes[3] = "A reference to the US Regional XML file was not found in the eCTD backbone.  "
				+ "Using ";
			mes[4] = "File path is incorrect or file could not be found.\\r\\nPlease check the file path and try again.";

			if(param > (mes.length-1)) return "";

			return mes[param];

		}

		]]>

	</msxsl:script>

	<xsl:template match="fda-regional:fda-regional"><!-- PROCESSING STARTS HERE -->

			<xsl:variable name="title" select="js:getTitle()"/> 

			<table width="100%" border="0" cellspacing="0" summary="This table contains the title of the XML transformation">
				<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('1')"/></xsl:attribute>
				<tr>
					<td align="center"> <!-- DOCUMENT TITLE -->
						<h2><xsl:value-of select="$title"/></h2>
					</td>
				</tr>
			</table>

			<table width="100%" bordercolor="#B9290D" border="1" cellspacing="0" summary="This table contains the XML instance summary information">
				<tr>
					<td>
						<table width="100%" border="0" cellspacing="0" cellpadding="4" bgcolor="white">
							<tr> 
								<td><xsl:attribute name="WIDTH"><xsl:value-of select="js:getIndent()"/></xsl:attribute></td>
								<td>
									<table width="100%" border="0" cellspacing="0" cellpadding="2" bgcolor="white">
										<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('2')"/></xsl:attribute>
										<tr>	<!-- SUMMARY INFORMATION (CUSTOMIZE AS NEEDED) -->
											<td valign="_top">
												Applicant Name:		<xsl:value-of select="admin/applicant-info/company-name"/><p />
												Application Number:	<xsl:value-of select="admin/product-description/application-number"/><p />
												Date of Submission	<xsl:value-of select="admin/applicant-info/date-of-submission/date"/><p />
												Product Name(s):	<xsl:for-each select="admin/product-description/prod-name"><xsl:value-of select="."/>&#160;</xsl:for-each>
											</td>
											<td valign="_top">
												Submission No.:		<xsl:value-of select="admin/application-information/submission/sequence-number"/><p/>
												Submission Type:	<xsl:value-of select="admin/application-information/submission/@submission-type"/><p/>
												Application Type:	<xsl:value-of select="admin/application-information/@application-type"/><p/>
												No. of Leaf Nodes:	<xsl:value-of select="count(descendant::leaf)"/>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table><br />

			<table align="center" width="100" border="0" cellspacing="0" summary="This table contains controls for displaying and hiding all document summaries">
				<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('1')"/></xsl:attribute>
				<tr>
					<td align="center">
						<input name="expandAll" type="button" value="Expand All" accesskey="e" title="Expand all document summaries">
							<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('10')"/></xsl:attribute>
							<xsl:attribute name="ONCLICK">
								var div=document.getElementsByTagName("div");
						
								for(i=0;i&lt;div.length;i++)
								{
									var divName = div[i].name;
									if(divName != null &amp;&amp; divName == "showData")
									{
										var a1=div[i].parentNode.firstChild.nextSibling.nextSibling;
										div[i].style.display="block";
										a1.title = "Collapse document summary";
									}
									if(divName != null &amp;&amp; divName == "expand")
									{
										div[i].style.display="none";
									}
									if(divName != null &amp;&amp; divName == "collapse")
									{
										div[i].style.display="inline";
									}
								}
								return false;
							</xsl:attribute>
						</input>
					</td>
					<td align="center">
						<input name="collapseAll" type="button" value="Collapse All" accesskey="c" title="Collapse all document summaries">
							<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('10')"/></xsl:attribute>
							<xsl:attribute name="ONCLICK">
								var div=document.getElementsByTagName("div");
								for(i=0;i&lt;div.length;i++)
								{
									var divName = div[i].name;
									if(divName != null &amp;&amp; divName == "showData")
									{
										var a1=div[i].parentNode.firstChild.nextSibling.nextSibling;
										div[i].style.display="none";
										a1.title = "Expand document summary";
									}
									if(divName != null &amp;&amp; divName == "expand")
									{
										div[i].style.display="inline";
									}
									if(divName != null &amp;&amp; divName == "collapse")
									{
										div[i].style.display="none";
									}
								}
								return false;
							</xsl:attribute>
						</input>
					</td>
				</tr>
		</table>

		<xsl:for-each select="descendant::node()">
			<xsl:if test="contains(name(),'m1-')
				or contains(name(),'m2-')
					or contains(name(),'m3-')
						or contains(name(),'m4-')
							or contains(name(),'m5-') or ../node-extension">
								<xsl:if test="leaf | node-extension/leaf | node-extension/node-extension/leaf">
									<xsl:if test="leaf">
										<br />
										<table width="100%" border="1" bordercolor="#787878" cellspacing="0" cellpadding="0" bgcolor="#787878" summary="This table contains the border for a section">
											<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule(0)"/></xsl:attribute>
											<tr>
												<td>
													<table width="100%" border="0" cellspacing="0" cellpadding="4" bgcolor="white" summary="This table contains background for a section">
														<tr> 
															<td><xsl:attribute name="WIDTH"><xsl:value-of select="js:getIndent()"/></xsl:attribute>
																<table width="100%" border="0" bordercolor="black" cellspacing="0" cellpadding="2" bgcolor="white" summary="This table contains the title of a section">
																	<tr>
																		<td height="10">
																		</td>
																	</tr>
																</table>
															</td>
															<td valign="center">
																<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('5')"/></xsl:attribute>
																<xsl:choose>
																	<xsl:when test="../node-extension">
																		<xsl:value-of select="js:getParentTitle()"/>
																		<xsl:for-each select="../node-extension">
																			-&#160;<xsl:value-of select="title"/>
																		</xsl:for-each>
																	</xsl:when>
																	<xsl:otherwise>
																		<xsl:variable name="module-title">
																			<xsl:value-of select="name()"/>
																			<xsl:for-each select="@indication">-<xsl:value-of select="."/></xsl:for-each>
																			<xsl:for-each select="@manufacturer">-<xsl:value-of select="."/></xsl:for-each>
																			<xsl:for-each select="@substance">-<xsl:value-of select="."/></xsl:for-each>
																			<xsl:for-each select="@dosageform">-<xsl:value-of select="."/></xsl:for-each>
																			<xsl:for-each select="@product-name">-<xsl:value-of select="."/></xsl:for-each>
																		</xsl:variable>
																		<xsl:value-of select="js:setParentTitle($module-title)"/>
																	</xsl:otherwise>
																</xsl:choose>			
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</table>
										<xsl:for-each select="leaf"> <!-- THIS HANDLES LEAVES AT THREE LEVELS -->
											<xsl:if test="@operation | @xlink:type">
												<table width="100%" border="0" cellspacing="0" cellpadding="4" bgcolor="#ECECEC" summary="This table contains the title of a document">
													<tr> 	
													<td><xsl:attribute name="WIDTH"><xsl:value-of select="js:getIndent()"/></xsl:attribute></td>
													<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('6')"/></xsl:attribute>
													<td align="left">
														<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('6')"/>></xsl:attribute>
														<a title="Open a secondary window that displays the indicated file"> <!-- OPENS A DOCUMENT -->
															<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('14')"/></xsl:attribute>
															<xsl:attribute name="HREF"></xsl:attribute>
															<xsl:attribute name="ONCLICK">
																
																// Vars
																var check = "";
																var displayFile = "";
																var displayLoc = "";
																var fileName = "<xsl:value-of select='@xlink:href'/>";
																var loads = null;
																var openLoc = null;
																var redundant = false;
																var selLoc = null;
																var sep = "/";
																var styleSheet = null;
																var subDirPath = null;
																var type = null;
																var xml = null;
																var style = null;
																var win = null;
																var winHeight = 0.70*window.screen.height;
																var winWidth = 0.75*window.screen.width;
																							
																openLoc = this.document.URL;
																if(openLoc != null &amp;&amp; openLoc.indexOf("\\") > -1) {
																	openLoc = openLoc.substring(0,openLoc.lastIndexOf("\\"));
																}
																							
																if(fileName.indexOf("/") == -1)
																{
																	sep = "\\";
																}
																
																check = fileName; // Set the directory name holder
																check = check.substring(0,check.lastIndexOf(sep));
							
																if(subDirPath == null)
																{
																	subDirPath = check;
																}
							
																while(check.indexOf(sep) &gt; -1) // Make sure URL pieces are unique
																{
																	check = check.substring(0,check.lastIndexOf(sep));
																	
																	if(openLoc.indexOf(check) &gt; 0 &amp;&amp;
																		!redundant) // Remove directory name overlap
																	{
																		fileName = fileName.substring(0,fileName.indexOf(check)-1);
																		redundant = true;
																	}
										
																}
																
																if(subDirPath != null &amp;&amp; selLoc != null &amp;&amp; selLoc.indexOf(subDirPath) &lt; 0)
																{
																	openLoc += sep + subDirPath;
																}
							
																if(!redundant)
																{
																	selLoc = openLoc + "\\" + fileName;
																}
															
																if(fileName != "") // If there is a file name, parse
																{
																	if(selLoc != "") {
																		try {
																			window.open(selLoc,"","alwaysRaised=yes,scrollbars=yes,menubar=yes,toolbar=yes,location=yes,status=yes,"
																				+ "resizable=yes,width=" + winWidth + ",height=" + winHeight+ ",left=120,top=50");
																		} catch(e) {
																			alert("<xsl:value-of select='js:getAlert(4)'/>");
																		}
																	} else {
																		alert("<xsl:value-of select='js:getAlert(4)'/>");
																	}
																}
																
																return false;
							
															</xsl:attribute>
															<xsl:choose>
																<xsl:when test="title and string-length(title) > 0">
																	<xsl:value-of select="title"/>
																</xsl:when>
																<xsl:otherwise>No Title</xsl:otherwise>
															</xsl:choose>
														</a>
														<a name="summary" href="" title="Expand document summary"> <!-- EXPANDS A SUMMARY -->
															<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('14')"/></xsl:attribute>
															<xsl:attribute name="ONCLICK">
																if (this.nextSibling.style.display=="block")
																{
																	this.nextSibling.style.display="none";
																	this.title = "Expand document summary";
																	this.firstChild.style.display="inline";
																	this.firstChild.nextSibling.style.display="none";
																}
																else
																{
																	this.nextSibling.style.display="block";
																	this.title = "Collapse document summary";
																	this.firstChild.style.display="none";
																	this.firstChild.nextSibling.style.display="inline";
																}
																return false;
															</xsl:attribute><div name="expand" style="position:relative; display=inline;">&#160;+</div><div name="collapse" style="position:relative; display=none;">&#160;-</div>
														</a> <!-- ADD FILE ATTRIBUTE VALUE NAME CHECKS HERE -->
														<div name="showData" style="position:relative; display=none;">
															<xsl:attribute name="STYLE"><xsl:value-of select="js:getCSSRule('9')"/></xsl:attribute>
															<xsl:attribute name="ID"><xsl:value-of select="js:getUnique()"/></xsl:attribute>
															&#160;Actuate = <xsl:value-of select="@actuate"/><br/>
															&#160;Application Version = <xsl:value-of select="@application-version"/><br/>
															&#160;Checksum = <xsl:value-of select="@checksum"/><xsl:value-of select="@md5-checksum"/><br/>
															&#160;Checksum Type = <xsl:value-of select="@checksum-type"/><br/>
															&#160;Filename = <xsl:value-of select="@xlink:href"/><br/>
															&#160;Font Library = <xsl:value-of select="@font-library"/><br/>
															&#160;ID = <xsl:value-of select="@ID"/><xsl:value-of select="@id"/><br/>
															&#160;Keywords = <xsl:value-of select="@keywords"/><br/>
															&#160;Language = <xsl:value-of select="@lang"/><br/>
															<xsl:if test="@modified-file"> &#160;Modified File = <xsl:value-of select="@modified-file"/><br/></xsl:if>
															&#160;Operation = <xsl:value-of select="@operation"/><br/> 
															&#160;Role = <xsl:value-of select="@xlink:role"/><br/>
															&#160;Show = <xsl:value-of select="@xlink:show"/><br/>
															&#160;Xlink = <xsl:value-of select="@xmlns:xlink"/><br/>
															&#160;Version = <xsl:value-of select="@version"/><br/>
														</div>
													</td>
												</tr>
											</table>
										</xsl:if>	
									</xsl:for-each>
							</xsl:if>
						</xsl:if>
					</xsl:if>
			</xsl:for-each>
	
	</xsl:template>

</xsl:stylesheet>