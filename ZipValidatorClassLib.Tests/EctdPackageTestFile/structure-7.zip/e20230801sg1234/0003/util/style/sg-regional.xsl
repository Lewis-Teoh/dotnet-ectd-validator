<?xml version="1.0" encoding="iso-8859-1" standalone="no"?>

<!--
	Singapore eCTD Module 1 Style-Sheet

	Version 1.0
	August 2023
-->

<xsl:stylesheet version="1.0"
	xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
	xmlns:xx="sg-hsa_ectd"
	xmlns:ectd="http://www.ich.org/ectd"
	xmlns:xlink="http://www.w3.org/1999/xlink"
	xmlns:xlink1="http://www.w3c.org/1999/xlink"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
   
   <xsl:output method="html" encoding="UTF-8" indent="yes"/>

   <xsl:param name="param_cv_producttype" select="'https://www.hsa.gov.sg/docs/default-source/hprg-tpb/ectd/xml/product-type.xml'"/>
   <xsl:param name="param_cv_applicationtype" select="'https://www.hsa.gov.sg/docs/default-source/hprg-tpb/ectd/xml/application-type.xml'"/>
   <xsl:param name="param_cv_sequencetype" select="'https://www.hsa.gov.sg/docs/default-source/hprg-tpb/ectd/xml/sequence-type.xml'"/>
   <xsl:param name="param_cv_contacttype" select="'https://www.hsa.gov.sg/docs/default-source/hprg-tpb/ectd/xml/contact-type.xml'"/>
   <xsl:param name="param_cv_submissiontype" select="'https://www.hsa.gov.sg/docs/default-source/hprg-tpb/ectd/xml/submission-type.xml'"/>
   
   <xsl:template match="/">
      <html>
         <head>
			<style type="text/css">
				body
				{
					font-family: "Segoe UI","Segoe UI Web Regular","Segoe UI Symbol","Helvetica Neue","Microsoft YaHei","BBAlpha Sans","S60 Sans",Arial,sans-serif !important;
					margin: 0;
					padding: 0;
				}

				
				h3 
				{
					margin-bottom:6pt;
					padding:6pt;
					background:#dddddd;
				}				

				h4 
				{	
					margin-top:0pt;
					margin-bottom:6pt;
				}				

				h5 
				{	
					font-size:12pt;
					background:#eeeeee;
					padding-top:6pt;
					padding-bottom:6pt;
					margin-bottom:0pt;
				}				

				ul {margin-bottom:0pt ; margin-top:0pt}

			</style>
			<title>Singapore HSA eCTD Module 1 - Schema version <xsl:value-of select="xx:sg-hsa_ectd/@schema-version"/></title>
         </head>
			<body>
				<center>
					<h1>Singapore HSA eCTD Module 1</h1>
					<small>Schema version <xsl:value-of select="xx:sg-hsa_ectd/@schema-version"/></small>
					<br/>
					<br/>
					<small>sg-regional.xml md5: <xsl:value-of select="document('../../index.xml')//m1-administrative-information-and-prescribing-information/leaf[@xlink1:href='m1/sg/sg-regional.xml']/@checksum"/></small>

				</center>
				
				
				<xsl:apply-templates select="//xx:sg-envelope"/>
				<br/>
				<xsl:apply-templates select="//xx:m1-sg"/>
			</body>
		</html>
	</xsl:template>
	
	<xsl:template match="xx:sg-envelope">
		<center>
			<table width="90%" border="1px" frame="border" rules="groups" cellpadding="2" cellspacing="0">
				<tr>
					<td colspan="2"><h3>Envelope</h3></td>
				</tr>
				<tr>
					<td colspan="2">
					<table width="100%" cellpadding="2" cellspacing="0" border="0">
						<tr>
							<th align="left" width="30%"><h5>Application</h5></th>
							<th align="left" width="70%"><h5><xsl:apply-templates select="xx:application/@code" mode="apptype"/></h5></th>
						</tr>
						<tr>
							<td>SG eCTD ID</td>
							<td><xsl:value-of select="xx:application/xx:sg-ectd-id"></xsl:value-of></td>
						</tr>
						<tr>
							<td valign="top">Application Number</td>
							<td><xsl:for-each select="xx:application/xx:application-number"><xsl:value-of select="."></xsl:value-of><br></br></xsl:for-each></td>
						</tr>
						<tr>
							<td valign="top">INN</td>
							<td><xsl:for-each select="xx:application/xx:inn"><xsl:value-of select="."></xsl:value-of><br></br></xsl:for-each></td>
						</tr>
						<tr>
							<td>Product Type</td>
							<td><xsl:apply-templates select="xx:application/xx:product-type/@code" mode="prodtype"/></td>
						</tr>
						<xsl:if test="xx:application/xx:dmf-number">
							<tr>
								<td valign="top">DMF Number</td>
								<td><xsl:for-each select="xx:application/xx:dmf-number"><xsl:value-of select="."></xsl:value-of><br></br></xsl:for-each></td>
							</tr>
						</xsl:if>
						<xsl:if test="xx:application/xx:pmf-number">
							<tr>
								<td valign="top">PMF Number</td>
								<td><xsl:for-each select="xx:application/xx:pmf-number"><xsl:value-of select="."></xsl:value-of><br></br></xsl:for-each></td>
							</tr>
						</xsl:if>
						<tr>
							<td valign="top">Proprietary Name</td>
							<td><xsl:for-each select="xx:application/xx:proprietary-name"><xsl:value-of select="."></xsl:value-of><br></br></xsl:for-each></td>
						</tr>
						<xsl:if test="xx:application/xx:sin-number">
							<tr>
								<td valign="top">Singapore Registration Number</td>
								<td><xsl:for-each select="xx:application/xx:sin-number"><xsl:value-of select="."></xsl:value-of><br></br></xsl:for-each></td>
							</tr>
						</xsl:if>
					</table>
					</td>
				</tr>

				<xsl:for-each select="xx:submission">
					<tr>
						<td colspan="2">
						<table width="100%" cellpadding="2" cellspacing="0" border="0">
							<tr>
								<th align="left" width="30%"><h5>Submission</h5></th>
								<th align="left" width="70%"><h5><xsl:apply-templates select="@code" mode="subtype"/></h5></th>
							</tr>
							<tr>
								<td valign="top">Submission Number</td>
								<td><xsl:for-each select="xx:submission-number"><xsl:value-of select="."></xsl:value-of><br></br></xsl:for-each></td>
							</tr>
						</table>
						</td>
					</tr>
				</xsl:for-each>

				<tr>
					<td colspan="2">
					<table width="100%" cellpadding="2" cellspacing="0" border="0">
						<tr>
							<th align="left" width="30%"><h5>Sequence</h5></th>
							<th align="left" width="70%"><h5><xsl:apply-templates select="xx:sequence/@code" mode="seqtype"/></h5></th>
						</tr>
						<tr>
							<td>Sequence Description</td>
							<td><xsl:value-of select="xx:sequence/xx:sequence-description"></xsl:value-of></td>
						</tr>
						<tr>
							<td>Sequence Date</td>
							<td><xsl:value-of select="xx:sequence/xx:sequence-date"></xsl:value-of></td>
						</tr>
						<tr>
							<td valign="top">Sequence Number</td>
							<td><xsl:for-each select="xx:sequence/xx:sequence-number"><xsl:value-of select="."></xsl:value-of><br></br></xsl:for-each></td>
						</tr>
						<tr>
							<td>Related Sequence Number</td>
							<td><xsl:value-of select="xx:sequence/xx:related-sequence-number"></xsl:value-of></td>
						</tr>
					</table>
					</td>
				</tr>

				<xsl:for-each select="xx:contact">
					<tr>
						<td colspan="2">
						<table width="100%" cellpadding="2" cellspacing="0" border="0">
							<tr>
								<th align="left" width="30%"><h5>Contact</h5></th>
								<th align="left" width="70%"><h5><xsl:apply-templates select="@code" mode="contacttype"/></h5></th>
							</tr>
							<tr>
								<td>Contact Name</td>
								<td><xsl:value-of select="xx:contact-name"></xsl:value-of></td>
							</tr>
							<tr>
								<td>Contact Email</td>
								<td><xsl:value-of select="xx:contact-email"></xsl:value-of></td>
							</tr>
							<tr>
								<td>Contact Phone</td>
								<td><xsl:value-of select="xx:contact-phone"></xsl:value-of></td>
							</tr>
						</table>
						</td>
					</tr>
				</xsl:for-each>

			</table>
		</center>
	</xsl:template>
	
	<xsl:template match="xx:leaf">
		<li>
			<a>
				<xsl:attribute name="href"><xsl:value-of select="@xlink:href"/></xsl:attribute>
				<xsl:value-of select="xx:title"/>
			</a>
			<xsl:text> </xsl:text>
			(<font color="red"><xsl:value-of select="@operation"/></font>)
			<xsl:if test="position() != last()"><br/></xsl:if>
		</li>
	</xsl:template>	
	
	<xsl:template match="xx:node-extension">
		<li><xsl:apply-templates select="xx:title" mode="data"/>
			<ul type="square">
				<xsl:apply-templates select="xx:leaf | xx:node-extension"/>
			</ul>
		</li>
	</xsl:template>


	<xsl:template match="@code" mode="apptype">
		<xsl:variable name='apptype' select='.'/>
		<xsl:choose>
			<xsl:when test='$param_cv_applicationtype and document($param_cv_applicationtype)/code-definition/codes/item[@code=$apptype]'>
				<xsl:value-of select="document($param_cv_applicationtype)/code-definition/codes/item[@code=$apptype]"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="."/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

	<xsl:template match="@code" mode="prodtype">
		<xsl:variable name='prodtype' select='.'/>
		<xsl:choose>
			<xsl:when test='$param_cv_producttype and document($param_cv_producttype)/code-definition/codes/item[@code=$prodtype]'>
				<xsl:value-of select="document($param_cv_producttype)/code-definition/codes/item[@code=$prodtype]"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="."/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>

	<xsl:template match="@code" mode="seqtype">
		<xsl:variable name='seqtype' select='.'/>
		<xsl:choose>
			<xsl:when test='$param_cv_sequencetype and document($param_cv_sequencetype)/code-definition/codes/item[@code=$seqtype]'>
				<xsl:value-of select="document($param_cv_sequencetype)/code-definition/codes/item[@code=$seqtype]"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="."/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>


	<xsl:template match="@code" mode="contacttype">
		<xsl:variable name='contacttype' select='.'/>
		<xsl:choose>
			<xsl:when test='$param_cv_contacttype and document($param_cv_contacttype)/code-definition/codes/item[@code=$contacttype]'>
				<xsl:value-of select="document($param_cv_contacttype)/code-definition/codes/item[@code=$contacttype]"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="."/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>


	<xsl:template match="@code" mode="subtype">
		<xsl:variable name='subtype' select='.'/>
		<xsl:choose>
			<xsl:when test='$param_cv_submissiontype and document($param_cv_submissiontype)/code-definition/codes/item[@code=$subtype]'>
				<xsl:value-of select="document($param_cv_submissiontype)/code-definition/codes/item[@code=$subtype]"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="."/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>



	<xsl:template match="xx:m1-sg">
		<center>
			<table width="90%" cellpadding="5" cellspacing="2">
				<tr>
					<td colspan="2"><h2>Module 1 Singapore eCTD</h2></td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h3>1.0</h3></td>
					<td width="95%">
						<h3>Correspondence</h3>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.0.1</h4></td>
					<td width="95%">
						<h4>Cover Letter</h4>
						<xsl:apply-templates select="//xx:m1-0-1-cover-letter/xx:leaf|//xx:m1-0-1-cover-letter/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.0.2</h4></td>
					<td width="95%">
						<h4>Note to Evaluator</h4>
						<xsl:apply-templates select="//xx:m1-0-2-note-evaluator/xx:leaf|//xx:m1-0-2-note-evaluator/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.0.3</h4></td>
					<td width="95%">
						<h4>Correspondence with HSA</h4>
						<xsl:apply-templates select="//xx:m1-0-3-hsa-correspondence/xx:leaf|//xx:m1-0-3-hsa-correspondence/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.0.4</h4></td>
					<td width="95%">
						<h4>Response to Input Request </h4>
						<xsl:apply-templates select="//xx:m1-0-4-response-hsa/xx:leaf|//xx:m1-0-4-response-hsa/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.0.5</h4></td>
					<td width="95%">
						<h4>Meeting Information</h4>
						<xsl:apply-templates select="//xx:m1-0-5-meeting-info/xx:leaf|//xx:m1-0-5-meeting-info/xx:node-extension"/>
					</td>
				</tr>
			
				
				<tr>
					<td valign="top"><h3>1.2</h3></td>
					<td>
						<h3>Administrative Information</h3>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.1</h4></td>
					<td width="95%">
						<h4>Application Forms</h4>
						<xsl:apply-templates select="//xx:m1-2-1-app-form/xx:leaf|//xx:m1-2-1-app-form/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h5>1.2.2</h5></td>
					<td width="95%">
						<h5>Checklists</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.2.1</h4></td>
					<td width="95%">
						<h4>Appendix 2a Checklist</h4>
						<xsl:apply-templates select="//xx:m1-2-2-1-2a/xx:leaf|//xx:m1-2-2-1-2a/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.2.2</h4></td>
					<td width="95%">
						<h4>Appendix 2b Checklist</h4>
						<xsl:apply-templates select="//xx:m1-2-2-2-2b/xx:leaf|//xx:m1-2-2-2-2b/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.2.3</h4></td>
					<td width="95%">
						<h4>Appendix 13a/14a Checklist</h4>
						<xsl:apply-templates select="//xx:m1-2-2-3-13a-14a/xx:leaf|//xx:m1-2-2-3-13a-14a/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.2.4</h4></td>
					<td width="95%">
						<h4>Appendix 13b/14b Checklist</h4>
						<xsl:apply-templates select="//xx:m1-2-2-4-13b-14b/xx:leaf|//xx:m1-2-2-4-13b-14b/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.2.5</h4></td>
					<td width="95%">
						<h4>Appendix 13c/14c Checklist</h4>
						<xsl:apply-templates select="//xx:m1-2-2-5-13c-14c/xx:leaf|//xx:m1-2-2-5-13c-14c/xx:node-extension"/>
					</td>
				</tr>

				<tr>
					<td width="5%" valign="top"><h5>1.2.3</h5></td>
					<td width="95%">
						<h5>Annexes</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.3.1</h4></td>
					<td width="95%">
						<h4>Letter of Authorisation from Product Owner</h4>
						<xsl:apply-templates select="//xx:m1-2-3-1-loa/xx:leaf|//xx:m1-2-3-1-loa/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h5>1.2.3.2</h5></td>
					<td width="95%">
						<h5>Change in Applicant</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.3.2.1</h4></td>
					<td width="95%">
						<h4>Letter of Authorisation from Product Owner to New Registrant</h4>
						<xsl:apply-templates select="//xx:m1-2-3-2-1-change-loa/xx:leaf|//xx:m1-2-3-2-1-change-loa/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.3.2.2</h4></td>
					<td width="95%">
						<h4>Written Confirmation of Hand-over of Dossier</h4>
						<xsl:apply-templates select="//xx:m1-2-3-2-2-confirmation-of-hand-over/xx:leaf|//xx:m1-2-3-2-2-confirmation-of-hand-over/xx:node-extension"/>
					</td>
				</tr>

				<tr>
					<td width="5%" valign="top"><h4>1.2.3.3</h4></td>
					<td width="95%">
						<h4>Declaration for Verification or Verification-CECA</h4>
						<xsl:apply-templates select="//xx:m1-2-3-3-decl-verif/xx:leaf|//xx:m1-2-3-3-decl-verif/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h5>1.2.3.4</h5></td>
					<td width="95%">
						<h5>Patent Declaration</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.3.4.1</h4></td>
					<td width="95%">
						<h4>Patent Declaration Form</h4>
						<xsl:apply-templates select="//xx:m1-2-3-4-1-pat-decl-form/xx:leaf|//xx:m1-2-3-4-1-pat-decl-form/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.3.4.2</h4></td>
					<td width="95%">
						<h4>Evidence of Authorisation</h4>
						<xsl:apply-templates select="//xx:m1-2-3-4-2-pat-evidence-auth/xx:leaf|//xx:m1-2-3-4-2-pat-evidence-auth/xx:node-extension"/>
					</td>
				</tr>

				<tr>
					<td width="5%" valign="top"><h4>1.2.4</h4></td>
					<td width="95%">
						<h4>Table of Summary of Changes</h4>
						<xsl:apply-templates select="//xx:m1-2-4-summary-of-changes/xx:leaf|//xx:m1-2-4-summary-of-changes/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.2.A</h4></td>
					<td width="95%">
						<h4>Additional Administrative Information</h4>
						<xsl:apply-templates select="//xx:m1-2-a-additional-admin-info/xx:leaf|//xx:m1-2-a-additional-admin-info/xx:node-extension"/>
					</td>
				</tr>
				
				
				<tr>
					<td width="5%" valign="top"><h3>1.3</h3></td>
					<td width="95%">
						<h3>Product Information</h3>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h5>1.3.1</h5></td>
					<td width="95%">
						<h5>Outer Carton Labels (OCL)</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.1.1</h4></td>
					<td width="95%">
						<h4>Approved - OCL</h4>
						<xsl:apply-templates select="//xx:m1-3-1-1-ocl-approved/xx:leaf|//xx:m1-3-1-1-ocl-approved/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.1.2</h4></td>
					<td width="95%">
						<h4>Clean Proposed - OCL</h4>
						<xsl:apply-templates select="//xx:m1-3-1-2-ocl-clean/xx:leaf|//xx:m1-3-1-2-ocl-clean/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.1.3</h4></td>
					<td width="95%">
						<h4>Annotated - OCL</h4>
						<xsl:apply-templates select="//xx:m1-3-1-3-ocl-annotated/xx:leaf|//xx:m1-3-1-3-ocl-annotated/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h5>1.3.2</h5></td>
					<td width="95%">
						<h5>Inner/Blister Labels (IBL)</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.2.1</h4></td>
					<td width="95%">
						<h4>Approved - IBL</h4>
						<xsl:apply-templates select="//xx:m1-3-2-1-ibl-approved/xx:leaf|//xx:m1-3-2-1-ibl-approved/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.2.2</h4></td>
					<td width="95%">
						<h4>Clean Proposed - IBL</h4>
						<xsl:apply-templates select="//xx:m1-3-2-2-ibl-clean/xx:leaf|//xx:m1-3-2-2-ibl-clean/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.2.3</h4></td>
					<td width="95%">
						<h4>Annotated - IBL</h4>
						<xsl:apply-templates select="//xx:m1-3-2-3-ibl-annotated/xx:leaf|//xx:m1-3-2-3-ibl-annotated/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h5>1.3.3</h5></td>
					<td width="95%">
						<h5>Package Insert (PI)</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.3.1</h4></td>
					<td width="95%">
						<h4>Approved - PI</h4>
						<xsl:apply-templates select="//xx:m1-3-3-1-pi-approved/xx:leaf|//xx:m1-3-3-1-pi-approved/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.3.2</h4></td>
					<td width="95%">
						<h4>Clean Proposed - PI</h4>
						<xsl:apply-templates select="//xx:m1-3-3-2-pi-clean/xx:leaf|//xx:m1-3-3-2-pi-clean/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.3.3</h4></td>
					<td width="95%">
						<h4>Annotated - PI</h4>
						<xsl:apply-templates select="//xx:m1-3-3-3-pi-annotated/xx:leaf|//xx:m1-3-3-3-pi-annotated/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h5>1.3.4</h5></td>
					<td width="95%">
						<h5>Patient Information Leaflet (PIL)</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.4.1</h4></td>
					<td width="95%">
						<h4>Approved - PIL</h4>
						<xsl:apply-templates select="//xx:m1-3-4-1-pil-approved/xx:leaf|//xx:m1-3-4-1-pil-approved/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.4.2</h4></td>
					<td width="95%">
						<h4>Clean Proposed - PIL</h4>
						<xsl:apply-templates select="//xx:m1-3-4-2-pil-clean/xx:leaf|//xx:m1-3-4-2-pil-clean/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.4.3</h4></td>
					<td width="95%">
						<h4>Annotated - PIL</h4>
						<xsl:apply-templates select="//xx:m1-3-4-3-pil-annotated/xx:leaf|//xx:m1-3-4-3-pil-annotated/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h5>1.3.5</h5></td>
					<td width="95%">
						<h5>Approved Foreign Labelling (SPC/PI/PIL)</h5>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.5.1</h4></td>
					<td width="95%">
						<h4>SPC/PI/PIL - Reference Agency</h4>
						<xsl:apply-templates select="//xx:m1-3-5-1-ref-foreign-label/xx:leaf|//xx:m1-3-5-1-ref-foreign-label/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.5.2</h4></td>
					<td width="95%">
						<h4>SPC/PI/PIL - Proof of Approval Agency</h4>
						<xsl:apply-templates select="//xx:m1-3-5-2-proof-approval-foreign-label/xx:leaf|//xx:m1-3-5-2-proof-approval-foreign-label/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td width="5%" valign="top"><h4>1.3.5.3</h4></td>
					<td width="95%">
						<h4>SPC/PI/PIL - Other Agency</h4>
						<xsl:apply-templates select="//xx:m1-3-5-3-other-foreign-label/xx:leaf|//xx:m1-3-5-3-other-foreign-label/xx:node-extension"/>
					</td>
				</tr>
				
				<tr>
					<td width="5%" valign="top"><h4>1.3.6</h4></td>
					<td width="95%">
						<h4>Declarations on Foreign Text/Braille</h4>
						<xsl:apply-templates select="//xx:m1-3-6-decl-foreign/xx:leaf|//xx:m1-3-6-decl-foreign/xx:node-extension"/>
					</td>
				</tr>
				

				<tr>
					<td valign="top"><h3>1.4</h3></td>
					<td>
						<h3>Information about the Experts</h3>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.4.1</h4></td>
					<td>
						<h4>Quality</h4>
						<xsl:apply-templates select="//xx:m1-4-1-quality/xx:leaf|//xx:m1-4-1-quality/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.4.2</h4></td>
					<td>
						<h4>Nonclinical</h4>
						<xsl:apply-templates select="//xx:m1-4-2-nonclinical/xx:leaf|//xx:m1-4-2-nonclinical/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.4.3</h4></td>
					<td>
						<h4>Clinical</h4>
						<xsl:apply-templates select="//xx:m1-4-3-clinical/xx:leaf|//xx:m1-4-3-clinical/xx:node-extension"/>
					</td>
				</tr>

				<tr>
					<td valign="top"><h3>1.5</h3></td>
					<td>
						<h3>Master Files and Certificates of Suitability</h3>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.5.1</h4></td>
					<td>
						<h4>DMF Acknowledgement Email</h4>
						<xsl:apply-templates select="//xx:m1-5-1-dmf-email/xx:leaf|//xx:m1-5-1-dmf-email/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h5>1.5.2</h5></td>
					<td>
						<h5>Letter of Access</h5>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.5.2.1</h4></td>
					<td>
						<h4>DMF Letter of Access</h4>
						<xsl:apply-templates select="//xx:m1-5-2-1-dmf-loaccess/xx:leaf|//xx:m1-5-2-1-dmf-loaccess/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.5.2.2</h4></td>
					<td>
						<h4>PMF Letter of Access</h4>
						<xsl:apply-templates select="//xx:m1-5-2-2-pmf-loaccess/xx:leaf|//xx:m1-5-2-2-pmf-loaccess/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.5.3</h4></td>
					<td>
						<h4>EMA Certificate for Plasma Master File (PMF)</h4>
						<xsl:apply-templates select="//xx:m1-5-3-ema-pmf/xx:leaf|//xx:m1-5-3-ema-pmf/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.5.4</h4></td>
					<td>
						<h4>Certificate of Suitability (CEP)</h4>
						<xsl:apply-templates select="//xx:m1-5-4-cep/xx:leaf|//xx:m1-5-4-cep/xx:node-extension"/>
					</td>
				</tr>

				<tr>
					<td valign="top"><h3>1.6</h3></td>
					<td>
						<h3>Environmental Risk Assessment</h3>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.6.1</h4></td>
					<td>
						<h4>Non-GMO</h4>
						<xsl:apply-templates select="//xx:m1-6-1-non-gmo/xx:leaf|//xx:m1-6-1-non-gmo/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.6.2</h4></td>
					<td>
						<h4>GMO</h4>
						<xsl:apply-templates select="//xx:m1-6-2-gmo/xx:leaf|//xx:m1-6-2-gmo/xx:lnode-extensioneaf"/>
					</td>
				</tr>

				<tr>
					<td valign="top"><h3>1.7</h3></td>
					<td>
						<h3>Good Manufacturing Practice</h3>
					</td>
				</tr>
				<tr>
					<td valign="top"><h5>1.7.1</h5></td>
					<td>
						<h5>GMP Certificates or Proof of GMP Compliance</h5>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.7.1.1</h4></td>
					<td>
						<h4>Drug Substance Manufacturers</h4>
						<xsl:apply-templates select="//xx:m1-7-1-1-drug-substance/xx:leaf|//xx:m1-7-1-1-drug-substance/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.7.1.2</h4></td>
					<td>
						<h4>Finished Pharmaceutical Product (FPP) Manufacturers</h4>
						<xsl:apply-templates select="//xx:m1-7-1-2-fpp/xx:leaf|//xx:m1-7-1-2-fpp/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.7.1.3</h4></td>
					<td>
						<h4>Batch Releaser</h4>
						<xsl:apply-templates select="//xx:m1-7-1-3-batch-releaser/xx:leaf|//xx:m1-7-1-3-batch-releaser/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.7.2</h4></td>
					<td>
						<h4>Description of Batch Numbering System</h4>
						<xsl:apply-templates select="//xx:m1-7-2-desc-batch-no-sys/xx:leaf|//xx:m1-7-2-desc-batch-no-sys/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h5>1.7.3</h5></td>
					<td>
						<h5>HSA GMP Conformity Assessment Application </h5>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.7.3.1</h4></td>
					<td>
						<h4>Application for GMP Evidence Evaluation</h4>
						<xsl:apply-templates select="//xx:m1-7-3-1-gmp-deva/xx:leaf|//xx:m1-7-3-1-gmp-deva/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.7.3.2</h4></td>
					<td>
						<h4>Application for Requesting an Overseas GMP Audit</h4>
						<xsl:apply-templates select="//xx:m1-7-3-2-gmp-oap/xx:leaf|//xx:m1-7-3-2-gmp-oap/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.7.A</h4></td>
					<td>
						<h4>Additional GMP Documents</h4>
						<xsl:apply-templates select="//xx:m1-7-a-additional-gmp/xx:leaf|//xx:m1-7-a-additional-gmp/xx:node-extension"/>
					</td>
				</tr>
				
				<tr>
					<td valign="top"><h3>1.8</h3></td>
					<td>
						<h3>Information Relating to Pharmacovigilance</h3>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.8.1</h4></td>
					<td>
						<h4>Singapore-Specific Annex</h4>
						<xsl:apply-templates select="//xx:m1-8-1-ssa/xx:leaf|//xx:m1-8-1-ssa/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.8.2</h4></td>
					<td>
						<h4>Reference RMP</h4>
						<xsl:apply-templates select="//xx:m1-8-2-ref-rmp/xx:leaf|//xx:m1-8-2-ref-rmp/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h5>1.8.3</h5></td>
					<td>
						<h5>Educational/RMP Materials</h5>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.8.3.1</h4></td>
					<td>
						<h4>Clean Proposed - Educational/RMP Materials</h4>
						<xsl:apply-templates select="//xx:m1-8-3-1-edu-rmp-mat-clean/xx:leaf|//xx:m1-8-3-1-edu-rmp-mat-clean/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.8.3.2</h4></td>
					<td>
						<h4>Annotated - Educational/RMP Materials</h4>
						<xsl:apply-templates select="//xx:m1-8-3-2-edu-rmp-mat-annotated/xx:leaf|//xx:m1-8-3-2-edu-rmp-mat-annotated/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.8.3.3</h4></td>
					<td>
						<h4>Finalised Artwork - Educational/RMP Materials</h4>
						<xsl:apply-templates select="//xx:m1-8-3-3-edu-rmp-mat-finalised/xx:leaf|//xx:m1-8-3-3-edu-rmp-mat-finalised/xx:node-extension"/>
					</td>
				</tr>

				<tr>
					<td valign="top"><h3>1.9</h3></td>
					<td>
						<h3>Foreign Regulatory Information</h3>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.9.1</h4></td>
					<td>
						<h4>Registration Status in Other Countries</h4>
						<xsl:apply-templates select="//xx:m1-9-1-status/xx:leaf|//xx:m1-9-1-status/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h5>1.9.2</h5></td>
					<td>
						<h5>Proof of Approval</h5>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.9.2.1</h4></td>
					<td>
						<h4>Proof of Approval from Reference Countries</h4>
						<xsl:apply-templates select="//xx:m1-9-2-1-proof-approval-ref/xx:leaf|//xx:m1-9-2-1-proof-approval-ref/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.9.2.2</h4></td>
					<td>
						<h4>Proof of Approval from Other Countries</h4>
						<xsl:apply-templates select="//xx:m1-9-2-2-proof-approval-other/xx:leaf|//xx:m1-9-2-2-proof-approval-other/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.9.3</h4></td>
					<td>
						<h4>Data Set Similarities and Differences</h4>
						<xsl:apply-templates select="//xx:m1-9-3-data-set-similarities/xx:leaf|//xx:m1-9-3-data-set-similarities/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.9.4</h4></td>
					<td>
						<h4>Foreign Evaluation/Assessment Reports</h4>
						<xsl:apply-templates select="//xx:m1-9-4-foreign-evaluation-reports/xx:leaf|//xx:m1-9-4-foreign-evaluation-reports/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.9.5</h4></td>
					<td>
						<h4>Appendix 18A Dossier Clarification Supplement</h4>
						<xsl:apply-templates select="//xx:m1-9-5-18a/xx:leaf|//xx:m1-9-5-18a/xx:node-extension"/>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.9.6</h4></td>
					<td>
						<h4>Declaration on Rejection, Withdrawal and Deferral</h4>
						<xsl:apply-templates select="//xx:m1-9-6-decl-rej-wd-def/xx:leaf|//xx:m1-9-6-decl-rej-wd-def/xx:node-extension"/>
					</td>
				</tr>

				<tr>
					<td valign="top"><h3>1.A</h3></td>
					<td>
						<h3>Additional Data</h3>
					</td>
				</tr>
				<tr>
					<td valign="top"><h4>1.A.1</h4></td>
					<td>
						<h4>Additional Data</h4>
						<xsl:apply-templates select="//xx:m1-a-1-additional-data/xx:leaf|//xx:m1-a-1-additional-data/xx:node-extension"/>
					</td>
				</tr>

			</table>
		</center>
	</xsl:template>
	
</xsl:stylesheet>
